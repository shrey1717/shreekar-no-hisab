---
name: Warm Neomorphic Student Fintech
colors:
  surface: '#fbf9f4'
  surface-dim: '#dbdad5'
  surface-bright: '#fbf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ee'
  surface-container: '#f0eee9'
  surface-container-high: '#eae8e3'
  surface-container-highest: '#e4e2dd'
  on-surface: '#1b1c19'
  on-surface-variant: '#59413d'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f1ec'
  outline: '#8d706c'
  outline-variant: '#e1bfb9'
  surface-tint: '#af2f1f'
  primary: '#ac2c1d'
  on-primary: '#ffffff'
  primary-container: '#ce4532'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb4a7'
  secondary: '#7c5800'
  on-secondary: '#ffffff'
  secondary-container: '#fec24a'
  on-secondary-container: '#715000'
  tertiary: '#5c5b62'
  on-tertiary: '#ffffff'
  tertiary-container: '#75747b'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad4'
  primary-fixed-dim: '#ffb4a7'
  on-primary-fixed: '#400100'
  on-primary-fixed-variant: '#8d1509'
  secondary-fixed: '#ffdea7'
  secondary-fixed-dim: '#f8bd45'
  on-secondary-fixed: '#271900'
  on-secondary-fixed-variant: '#5e4200'
  tertiary-fixed: '#e4e1ea'
  tertiary-fixed-dim: '#c8c5cd'
  on-tertiary-fixed: '#1b1b21'
  on-tertiary-fixed-variant: '#47464d'
  background: '#fbf9f4'
  on-background: '#1b1c19'
  surface-variant: '#e4e2dd'
  surface-card: '#FFFFFF'
  surface-cream: '#F9F8F5'
  text-primary: '#19181A'
  text-secondary: '#76747A'
  text-tertiary: '#A5A3A8'
  status-owe: '#F05D48'
  status-owe-bg: '#FEECE9'
  status-receive: '#1DB974'
  status-receive-bg: '#E8F8F0'
  accent-yellow-light: '#FFF7E3'
  border-subtle: '#EDEAE3'
  bar-gradient-start: '#F05D48'
  bar-gradient-end: '#F4B942'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '800'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  currency-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.03em
  currency-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 36px
    letterSpacing: -0.02em
  currency-card:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
  pill-badge:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.25rem
  space-xl: 1.75rem
---

## Brand & Style

The design system is crafted for communal living, student camaraderie, and frictionless peer-to-peer balance tracking. Designed for college hostel mates and shared living circles, it balances financial accountability with friendly, low-stress interactions. Money discussions among roommates can easily turn awkward; this system replaces transactional coldness with approachable warmth, clarity, and tactile delight.

The visual direction draws directly from modern soft UI and tactile warmth—blending crisp minimalist typography with pillowy, soft-curved cards, pill badges, and dual-tone warm accents. The aesthetic relies on clean off-white card surfaces floating above warm cream-tinted canvases, anchored by an energetic coral primary accent (`#F05D48`) and an uplifting golden amber (`#F4B942`) for highlights and active states. 

Contrasting dark charcoal containers (`#1E1E24`) are used strategically for summary metrics and high-impact balance callouts, giving the interface instant visual hierarchy. Rupee currency values (`₹`) are treated as primary hero objects with tight tracking, distinct numerals, and unmistakable debt-state tagging ("You owe" in soft terracotta/coral and "Owes you" in fresh emerald mint).

## Colors

The palette establishes an upbeat, approachable vibe that departs from conventional sterile fintech blues. 

- **Primary (`#F05D48`)**: A vibrant energetic coral-red used for hero calls-to-action (Floating 'Add Expense' buttons, active tab pill anchors, urgent settlement actions, and 'You owe' warnings).
- **Secondary (`#F4B942`)**: A warm golden marigold yellow, representing active states, milestone highlights, split proportion bars, and shared achievements.
- **Tertiary (`#1E1E24`)**: Deep obsidian charcoal, applied to high-contrast summary tiles, major metric headers, and night/hero callout cards.
- **Neutral (`#F7F5F0`)**: A warm almond-cream background tone that gives the app an organic, friendly paper-like base, avoiding harsh pure-white glare.

### Semantic Status Palette
- **You Owe (Debt)**: Solid coral text on `#FEECE9` tint. Unmistakable but polite.
- **Owes You (Credit)**: Clear forest/mint emerald (`#1DB974`) on `#E8F8F0` pill backgrounds.
- **Settled / Even**: Warm neutral pill with `#76747A` typography.

## Typography

Typography is powered entirely by **Plus Jakarta Sans**, providing clean geometric construction, wide apertures, and friendly rounded terminals that feel warm and modern.

### Numerical & Rupee Formatting
Amounts require immediate readability without scanning friction:
- Always prefix the currency glyph with no space before the integer: `₹1,450.00`.
- Use tabular/lining figures in financial rows and balance sheets so decimal points align vertically across friends and split participants.
- The `currency-hero` token anchors top balance cards, while `currency-card` presents individual debts.
- Group and section category labels utilize `label-caps` (`font-bold`, uppercase, tracking `0.06em`) in `#76747A` to provide clear, calm rhythm without competing with actual expenses.

## Layout & Spacing

The layout philosophy is mobile-first fluid with a strict responsive constraint. While operating on wide web browsers, the core interface remains centered inside a max-width container (`480px` for mobile app emulation, expanding to an ergonomic multi-column dashboard grid on desktop up to `1080px`).

### Mobile Model
- **Outer Canvas Margins**: `1.25rem` (20px) horizontal inset from screen edges.
- **Card Padding**: Generous internal spacing (`1.25rem` to `1.5rem`), preventing cluttered finance tables.
- **Element Gaps**: Grouped list items use `space-sm` (8px) gaps, while major module transitions leverage `space-xl` (28px) rhythm.
- **Sticky Actions**: The bottom navigation and contextual actions (e.g., floating "Add Expense" coral rounded pill) float within reach of single-thumb navigation, leaving `84px` of padding at the bottom of scroll containers.

## Elevation & Depth

Visual depth is achieved through tactile, low-contrast ambient shadows and floating card layers rather than harsh structural borders.

### Surface Tiers
1. **Base Canvas**: Warm creamy eggshell (`#F7F5F0`).
2. **Elevated Cards**: Pure White (`#FFFFFF`) with a diffuse warm ambient shadow (`box-shadow: 0 10px 30px -4px rgba(80, 60, 40, 0.06), 0 2px 6px -1px rgba(0, 0, 0, 0.03)`).
3. **Hero Dark Container**: Solid Charcoal (`#1E1E24`) paired with an interior soft glow or high-contrast yellow graphic discs to create strong focal weight.
4. **Floating Action Buttons & Badges**: Soft pillowy elevation with coral-tinted ambient glow (`box-shadow: 0 8px 20px -2px rgba(240, 93, 72, 0.35)`).

Elements interact through tactile state changes: buttons slightly depress on tap (`scale(0.97)`), and hovering cards produce an upward floating translation of `-2px`.

## Shapes

The design system embraces generous, pillowy corner curvature that eliminates sharp intimidation from expense tracking.

- **Primary Cards**: `rounded-2xl` (1.25rem / 20px to 1.5rem / 24px) providing soft, organic enclosure for transactions, group summaries, and charts.
- **Pill Badges & Buttons**: Full pill radius (`rounded-full` / 9999px) for settlement chips, category indicators, and filter triggers.
- **Input Fields & Form Selectors**: `rounded-xl` (0.75rem / 12px) for structured, comfortable tap zones.
- **Progress & Ratio Bars**: Pill-shaped caps with smooth rounded ends (`rounded-full`), preventing harsh rectangular cuts on split graphs.

## Components

### 1. Balance Summary Card (Dark Hero)
- **Container**: Rich charcoal `#1E1E24` surface, `rounded-3xl`, padded with `1.5rem`.
- **Content**: White text displaying net balance (`₹1,850.00`) alongside status subtext ("You are owed in total").
- **Visual Element**: Warm geometric accent on the right side using overlapping `#F4B942` yellow rounded pill or coin discs, communicating prosperity and communal hostel energy.

### 2. Transaction & Member Rows
- **Container**: Pure white card with subtle border (`1px solid #EDEAE3`) and `rounded-2xl` corners.
- **Avatar**: `44px` circular avatar with soft warm border or initials in bold terracotta.
- **Title & Metadata**: Top row with member/expense name in `title-md`; bottom row with date and split share description in `body-sm` (`#76747A`).
- **Trailing Balance**: Prominent currency pill badge:
  - If member owes user: Text in `#1DB974` with background `#E8F8F0`.
  - If user owes member: Text in `#F05D48` with background `#FEECE9`.

### 3. Action Buttons & FAB
- **Floating 'Add Expense' Button**: Squircle or pill shape in vibrant coral (`#F05D48`), white icon/typography, elevated by soft coral shadow (`rgba(240, 93, 72, 0.35)`).
- **Secondary Actions**: Warm cream pill (`#F9F8F5`), border `1px solid #EDEAE3`, with dark charcoal text.
- **Settle Up Button**: Full-width high-emphasis coral pill with slight inner warmth.

### 4. Progress & Split Ratio Bars
- Segmented multi-participant bar with `12px` height, fully rounded pill ends.
- Gradient fill running from `#F05D48` (Coral) to `#F4B942` (Golden Amber) representing percentage split distribution and hostel budget limits.
- Background trough colored in soft `#EDEAE3`.

### 5. Input Fields (Add Expense & Split Form)
- Height `52px`, `rounded-xl`, background `#FFFFFF`, border `1.5px solid #EDEAE3`.
- Active focus state swaps border to `#F05D48` with a subtle `3px` translucent ring (`rgba(240, 93, 72, 0.15)`).
- Prefix slot for the `₹` symbol in bold `18px` charcoal text.

### 6. Bottom Navigation Bar
- Docked floating pill container at the bottom screen edge, background `#FFFFFF` with blur backdrop or solid coral footer segment.
- Active tab indicated by a smooth pill container (`#FEECE9` background with `#F05D48` icon and text label).